These are sample *boolean MDP and POMDP track* files from the
IPPC 2011 final competition.  Only the first of ten instances
in RDDL and the different translations are provided.

For the full archive of final competition problems, please
use either of the following links (one .tgz, one .zip):

  http://users.cecs.anu.edu.au/~ssanner/IPPC_2011/final_competition_42311.tgz
  http://users.cecs.anu.edu.au/~ssanner/IPPC_2011/final_competition_42311.zip

NOTE: For speed of simulation, state-action-constraints were
commented out in all of the RDDL files although if you are
using a regression-based planner, you might want to uncomment
and exploit this constraint information.
