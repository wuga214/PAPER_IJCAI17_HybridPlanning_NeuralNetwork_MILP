These are sample *boolean MDP and POMDP track* files from the
IPPC 2014 final competition.  

For the full archive of final competition problems, please
use either of the following links (one .tgz, one .zip):

  http://users.cecs.anu.edu.au/~ssanner/IPPC_2014/final_competition_2014_all.zip
  http://users.cecs.anu.edu.au/~ssanner/IPPC_2014/final_competition_2014_all.tgz
