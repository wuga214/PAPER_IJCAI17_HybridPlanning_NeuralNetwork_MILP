This directory contains a variety of general RDDL domains
exhibiting intermediate variables, non-boolean fluents, etc.

Most of these domains are *too* expressive to satisfy the
boolean track requirements of the IPPC 2011.
