package rddl.solver;

public class TimeOutException extends Exception {
	public TimeOutException(String msg) {
		super(msg);
	}
}
